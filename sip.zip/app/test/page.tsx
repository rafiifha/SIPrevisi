export default function TestPage() {
  return (
    <div style={{ padding: '50px', background: 'white' }}>
      <h1 style={{ color: 'black' }}>Test Page Works!</h1>
      <p>If you see this, Next.js is rendering correctly.</p>
    </div>
  )
}